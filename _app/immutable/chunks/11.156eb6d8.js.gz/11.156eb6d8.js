import{default as t}from"../entry/(blog-article)-swift-page.md.cf81a573.js";export{t as component};
