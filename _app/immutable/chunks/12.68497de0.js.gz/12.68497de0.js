import{default as t}from"../entry/(blog-article)-tardigrades-page.md.fba6c1a4.js";export{t as component};
