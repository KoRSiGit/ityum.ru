import{default as t}from"../entry/(subject-article)-culturology-page.md.fc988c17.js";export{t as component};
