import{default as t}from"../entry/(waves)-page.svelte.5de9a52a.js";export{t as component};
