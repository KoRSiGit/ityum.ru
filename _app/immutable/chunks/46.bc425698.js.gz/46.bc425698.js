import{default as t}from"../entry/(waves)-slide-eng-page.svelte.9ead2616.js";export{t as component};
