import{default as t}from"../entry/(geocard)-prjev-page.md.977dcec7.js";export{t as component};
