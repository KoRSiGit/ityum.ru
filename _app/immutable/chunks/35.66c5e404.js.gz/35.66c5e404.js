import{default as t}from"../entry/(subject-article)-russian-formation-page.md.756c89bf.js";export{t as component};
