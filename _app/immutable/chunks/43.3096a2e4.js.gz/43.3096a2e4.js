import{_ as r}from"./_page.f1a8916d.js";import{default as t}from"../entry/(waves)-quiz-schools-page.svelte.18e8852a.js";export{t as component,r as universal};
