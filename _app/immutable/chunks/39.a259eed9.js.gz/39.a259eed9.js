import{default as t}from"../entry/(waves)-flashcards-page.svelte.e41854f0.js";export{t as component};
