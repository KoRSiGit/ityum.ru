import{default as t}from"../entry/(subject-article)-literature-review-page.md.7c9d57b4.js";export{t as component};
