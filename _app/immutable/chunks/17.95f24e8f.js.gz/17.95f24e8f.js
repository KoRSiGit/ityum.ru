import{default as t}from"../entry/(flashcard)-mandatory-page.md.ea812af3.js";export{t as component};
