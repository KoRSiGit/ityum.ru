import{default as t}from"../entry/(geocard)-lis_kruz-page.md.1f705526.js";export{t as component};
