import{default as t}from"../entry/(waves)-layout.svelte.7a617cfb.js";export{t as component};
