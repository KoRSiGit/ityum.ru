import{default as t}from"../entry/(geocard)-layout.svelte.d2061866.js";export{t as component};
