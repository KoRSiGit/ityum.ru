import{default as t}from"../entry/(geocard)-mikl-page.md.a2d40246.js";export{t as component};
